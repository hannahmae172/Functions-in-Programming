var dragon = 10 
var fire = 3 
var ice = 1 
var poison = 4 
function defeatthedragon(name, health){
  var ele = document.createElement("div");
  ele.innerHTML=name+"-"+health; 
  document.body.appendChild(ele);
}
for(var i=0; i<1; i++){
  defeatthedragon("dragon", dragon);
}
document.body.querySelector(".Fbutton").addEventListener("click", function(){
  defeatthedragon("dragon", dragon=dragon-fire+1);
})
document.body.querySelector(".Ibutton").addEventlistener("click", function(){
  defeatthedragon("dragon", dragon=dragon-ice-1);
})
document.body.querySelector(".Pbutton").addEventListener("click", function(){
  defeatthedragon("dragon", dragon=dragon-poison);
})
if(0>=dragon){
  document.body.querySelector(".win").innerHTML="player wins";
}