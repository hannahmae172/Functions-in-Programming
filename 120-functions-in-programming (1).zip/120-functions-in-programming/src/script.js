var fireButton = document.createElement("button");
var iceButton = document.createElement("button");
var poisonButton = document.createElement("button");
var dragon = document.createElement("div");
var winner = document.createElement("div");

var slaythedragon = 0;

fireButton.innerHTML = "Fire";
iceButton.innerHTML = "Ice";
poisonButton.innerHTML = "Poison";
dragon.innerHTML = "slaythedragon:" + slaythedragon;

fireButton.addEventListener("click", function () {
  attack(3, "fire");
});
iceButton.addEventListener("click", function () {
  attack(1, "ice");
});
poisonButton.addEventListener("click", function () {
  attack(4, "poison");
});

function attack(damage, attackType) {
  if (attackType == "fire") {
   slaythedragon = slaythedragon + (damage - 1);
  } else if (attackType == "ice") {
    slaythedragon = slaythedragon + (damage + 1);
  } else {
   slaythedragon = slaythedragon + damage;
  }
  
  dragon.innerHTML = "slaythedragon: " + slaythedragon;

  if (slaythedragon >= 10) {
    winner.innerHTML = "You win!";
  }
}

document.body.appendChild(fireButton);
document.body.appendChild(iceButton);
document.body.appendChild(poisonButton);
document.body.appendChild(dragon);
document.body.appendChild(winner);